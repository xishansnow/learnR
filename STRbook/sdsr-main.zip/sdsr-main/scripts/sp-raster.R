
## library(sp)
## y = as(x, "Spatial")



## x0 = st_as_sf(y)



## x = as(sf::read_sf("file"), "Spatial")

